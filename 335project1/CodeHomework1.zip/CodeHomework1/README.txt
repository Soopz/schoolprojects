Jeffrey Chen
CSCI 335 PROJECT 1 

1. All parts of my project have been finished and all member functions have been written.

2. I have not encountered any substantial bugs

3. Make all to compile and use ./test_points2<test_input_file.txt
