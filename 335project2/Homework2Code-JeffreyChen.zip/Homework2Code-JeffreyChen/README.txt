Jeffrey Chen
CSCI 335 PROJECT 2 

1.All parts of my project have been finished

2.I had trouble getting the exact numbers the were expected

3. Make all to compile use:
./query_tree rebase210.txt < input_part2a.txt
./test_tree rebase210.txt sequences.txt
./test_tree_mod rebase210.txt sequences.txt