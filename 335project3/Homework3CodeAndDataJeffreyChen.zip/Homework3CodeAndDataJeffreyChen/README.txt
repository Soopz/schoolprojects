Jeffrey Chen
CSCI 335 PROJECT 3

1.All parts of my project have been finished

2. I didn't include cases for apostrophes and hyphens

3. Make all to compile use:
./create_and_test_hash words.txt query_words.txt quadratic
./create_and_test_hash words.txt query_words.txt linear
./create_and_test_hash words.txt query_words.txt double
./spell_check document1_short.txt wordsEn.txt
./spell_check document1.txt wordsEn.txt